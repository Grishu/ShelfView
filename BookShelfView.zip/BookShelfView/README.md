android-bookshelf-example
=========================

Bookshelf Example - Android App Skeleton