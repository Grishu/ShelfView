package org.example.bookshelf.adapter;

import java.util.List;

import org.example.bookshelf.Book_DataModel;
import org.example.bookshelf.R;
import org.example.bookshelf.view.ImageLoader;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.Toast;

public class BooksAdapter extends BaseAdapter {

	private Context context;
	private final List<Book_DataModel> books;
	LayoutInflater inflater;
	ImageLoader mImageLoader;

	public BooksAdapter(Context context, List<Book_DataModel> books) {

		this.context = context;
		this.books = books;
	}

	@Override
	public Book_DataModel getItem(int position) {
		return books.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public int getCount() {
		return books.size();
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		inflater = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		// View gridView = null;
		// gridView = new View(context);
		if (convertView == null) {
			// BookDto book = books.get(position);
			// if (book != null) {
			// if (convertView == null) {

			convertView = inflater.inflate(R.layout.item, null);
			// try {
			// Bitmap icon = BitmapFactory.decodeStream((new
			// URL(books.get(position)
			// .getBook_cover_image())).openConnection().getInputStream());
			// TextView textView = (TextView)
			// convertView.findViewById(R.id.grid_item_label);
			// textView.setText(books.get(position).getBook_title());
			// get layout from mobile.xml
			System.out.println("Image Thumb Url===>"
					+ books.get(position).getBook_cover_image().toString());
			ImageView imageView = (ImageView) convertView.findViewById(R.id.grid_item_cover);
			// mImageLoader = new ImageLoader(context, false,
			// R.drawable.ic_launcher);
			mImageLoader = new ImageLoader(context, 180, 180, false, R.drawable.ic_launcher);
			mImageLoader.DisplayImage(books.get(position).getBook_cover_image(), imageView);
			// imageView.setImageBitmap(icon);
			// } catch (MalformedURLException e) {
			// // TODO Auto-generated catch block
			// e.printStackTrace();
			// } catch (IOException e) {
			// // TODO Auto-generated catch block
			// e.printStackTrace();
			// }
			// }

			// ImageView imageView = (ImageView)
			// gridView.findViewById(R.id.grid_item_new);
			// imageView.setVisibility(book.isNewItem() ? View.VISIBLE :
			// View.INVISIBLE);

			// } else {
			// gridView = (View) convertView;
			// }}

			imageView.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					String toast = "Item Title==" + books.get(position).getBook_title()
							+ "\n Book Language==>" + books.get(position).getBook_language()
							+ "\n Descrip==>" + books.get(position).getBook_description()
							+ "\n Book Url==>" + books.get(position).getBook();
					System.out.println(toast);
					Toast.makeText(context, toast, Toast.LENGTH_SHORT).show();

				}
			});
		}
		return convertView;
	}

}
