package org.example.bookshelf.xml;

import java.util.ArrayList;
import java.util.List;

import org.example.bookshelf.Book_DataModel;
import org.example.bookshelf.activity.CommonClass;
import org.example.bookshelf.activity.CommonUtils;
import org.example.bookshelf.adapter.BooksAdapter;
import org.example.bookshelf.view.BookshelfView;
import org.json.JSONArray;
import org.json.JSONObject;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

public class DownloadBooksTask extends AsyncTask<String, Void, List<Book_DataModel>> {

	private Context context;
	private BookshelfView view;
	private CommonClass mCommonClass;
	private String m_response = "";
	private List<Book_DataModel> bookData;
	public DownloadBooksTask(Context context, BookshelfView view) {
		super();
		this.context = context;
		this.view = view;
		mCommonClass = new CommonClass();
		bookData = new ArrayList<Book_DataModel>();
	}

	@Override
	protected void onPreExecute() {
		super.onPreExecute();
	}

	@Override
	protected List<Book_DataModel> doInBackground(String... params) {
//		if ((params == null) || (params.length != 1)) {
//			throw new IllegalArgumentException("The URL is expected as a parameter.");
//		}

		/*
		 * InputStream is = null; try { is = download(params[0]); if (is !=
		 * null) { return (new BooksXmlParser()).parse(is); }
		 * 
		 * } catch (XmlPullParserException e) { // TODO Auto-generated catch
		 * block e.printStackTrace(); } catch (IOException e) { // TODO
		 * Auto-generated catch block e.printStackTrace();
		 * 
		 * } finally { if (is != null) { try { is.close(); } catch (IOException
		 * e) { // TODO Auto-generated catch block e.printStackTrace(); } } }
		 * return null;
		 */
		if (mCommonClass.CheckNetwork(context)) {
			m_response = CommonUtils
					.parseJSON("http://180.211.110.195/php-projects/vachanamrut/webservice/ListOfBooks");
			Log.v("DATA", "All Data ====== " + m_response);
		}
		try {
			JSONArray m_arr = new JSONArray(m_response);
			for (int i = 0; i < m_arr.length(); i++) {
				Log.e("TAG", "book id  = " + m_arr.getJSONObject(i).getInt("book_id"));
				JSONObject m_jObj = m_arr.getJSONObject(i);
				bookData.add(new Book_DataModel(m_jObj.getInt("book_id"), m_jObj
						.getString("book_title"), m_jObj.getString("book_author"), m_jObj
						.getString("book_description"), m_jObj.getString("book_cover_image"),
						m_jObj.getString("book"), m_jObj.getString("book_language"), m_jObj
								.getInt("status"), m_jObj.getInt("deleted"), m_jObj
								.getInt("created_dt"), m_jObj.getInt("updated_dt"), m_jObj
								.getInt("updated_by")));
			}
			System.err.println("Size of array====>"+m_arr.length());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return bookData;
	}

	@Override
	protected void onPostExecute(List<Book_DataModel> result) {
		super.onPostExecute(result);

		if (result != null) {
			view.setAdapter(new BooksAdapter(context, result));
		} else {
			(Toast.makeText(context, "An error occured.", Toast.LENGTH_LONG)).show();
		}
	}

//	protected InputStream download(String urlString) throws IOException {
//		HttpURLConnection conn = (HttpURLConnection) (new URL(urlString)).openConnection();
//		conn.setReadTimeout(10000);
//		conn.setConnectTimeout(15000);
//		conn.setRequestMethod("GET");
//		conn.setDoInput(true);
//
//		conn.connect();
//		return conn.getInputStream();
//	}
}
