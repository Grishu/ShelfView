/** Automatically generated file. DO NOT MODIFY */
package org.curiouscreature.android.shelves;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}